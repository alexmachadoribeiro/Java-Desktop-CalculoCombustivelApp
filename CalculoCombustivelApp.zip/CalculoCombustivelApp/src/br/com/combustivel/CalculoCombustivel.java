package br.com.combustivel;

public final class CalculoCombustivel implements CalculoCombustivelInterface {
	private double etanol;
	private double gasolina;
	
	public CalculoCombustivel() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String calcularCombustivel() {
		// TODO Auto-generated method stub
		if (this.etanol/this.gasolina >= 0.7)
			return "Melhor abastecer com gasolina";
		else
			return "Melhor abastecer com etanol";
	}

	public double getEtanol() {
		return etanol;
	}

	public void setEtanol(double etanol) {
		this.etanol = etanol;
	}

	public double getGasolina() {
		return gasolina;
	}

	public void setGasolina(double gasolina) {
		this.gasolina = gasolina;
	}

}
