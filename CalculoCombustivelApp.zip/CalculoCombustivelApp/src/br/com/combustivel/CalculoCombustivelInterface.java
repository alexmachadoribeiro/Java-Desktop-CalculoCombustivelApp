package br.com.combustivel;

public interface CalculoCombustivelInterface {
	public String calcularCombustivel();
}
