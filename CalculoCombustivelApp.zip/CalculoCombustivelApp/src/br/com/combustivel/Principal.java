package br.com.combustivel;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CalculoCombustivel combustivel = new CalculoCombustivel();
		
		Object[] opcao = {"Informar valores", "Sair"};
		Object selecionarOpcao;
		
		String etanol;
		String gasolina;
		
		do {
			selecionarOpcao = JOptionPane.showInputDialog(null, "Escolha uma op��o:", "Op��o", JOptionPane.INFORMATION_MESSAGE, null, opcao, opcao[0]);
			
			if (selecionarOpcao == "Informar valores") {
				gasolina = JOptionPane.showInputDialog("Informe o valor da gasolina:");
				etanol = JOptionPane.showInputDialog("Informe o valor do etanol:");
				
				gasolina = gasolina.replace(",", ".");
				etanol = etanol.replace(",", ".");
				
				combustivel.setGasolina(Double.parseDouble(gasolina));
				combustivel.setEtanol(Double.parseDouble(etanol));
				
				JOptionPane.showMessageDialog(null, combustivel.calcularCombustivel());
				
			}
		} while (selecionarOpcao != "Sair");

	}

}
